<?php
/**
 * @author    Oceanpayment Team
 * @copyright Copyright (c) 2018 Oceanpayment.COM
 */
 

class OPAlipayhkNoticeModuleFrontController extends ModuleFrontController
{
    public function initContent()
    {

    	//获取推送输入流XML
    	$xml_str = file_get_contents("php://input");
    	
    	//判断返回的输入流是否为xml
    	if($this->xml_parser($xml_str)){
    		$xml = simplexml_load_string($xml_str);
    	

    		//把推送参数赋值到$_REQUEST
    		if(!isset($xml->response_type)){
    		    //其他业务情况推送
    		    $_REQUEST['account']		  = (string)$xml->account;
    		    $_REQUEST['terminal'] 	      = (string)$xml->terminal;
    		    $_REQUEST['signValue'] 	      = (string)$xml->signValue;
    		    $_REQUEST['payment_id'] 	  = (string)$xml->payment_id;
    		    $_REQUEST['order_number']     = (string)$xml->order_number;
    		    $_REQUEST['order_currency']   = (string)$xml->order_currency;
    		    $_REQUEST['order_amount']     = (string)$xml->order_amount;
    		    $_REQUEST['card_type']        = (string)$xml->card_type;
    		    $_REQUEST['notice_type']      = (string)$xml->notice_type;
    		    $_REQUEST['push_id']          = (string)$xml->push_id;
    		    $_REQUEST['push_status']	  = (string)$xml->push_status;
    		    $_REQUEST['push_details']     = (string)$xml->push_details;
    		    $_REQUEST['payment_dateTime'] = (string)$xml->payment_dateTime;
    		    $_REQUEST['push_dateTime']    = (string)$xml->push_dateTime;
    		    $_REQUEST['refund_number']    = (string)$xml->refund_number;
    		    
    		}else{
    		    //交易推送
    		    $_REQUEST['response_type']	  = (string)$xml->response_type;
    		    $_REQUEST['account']		  = (string)$xml->account;
    		    $_REQUEST['terminal'] 	      = (string)$xml->terminal;
    		    $_REQUEST['payment_id'] 	  = (string)$xml->payment_id;
    		    $_REQUEST['order_number']     = (string)$xml->order_number;
    		    $_REQUEST['order_currency']   = (string)$xml->order_currency;
    		    $_REQUEST['order_amount']     = (string)$xml->order_amount;
    		    $_REQUEST['payment_status']   = (string)$xml->payment_status;
    		    $_REQUEST['payment_details']  = (string)$xml->payment_details;
    		    $_REQUEST['signValue'] 	      = (string)$xml->signValue;
    		    $_REQUEST['order_notes']	  = (string)$xml->order_notes;
    		    $_REQUEST['card_number']	  = (string)$xml->card_number;
    		    $_REQUEST['payment_authType'] = (string)$xml->payment_authType;
    		    $_REQUEST['payment_risk'] 	  = (string)$xml->payment_risk;
    		    $_REQUEST['methods'] 	  	  = (string)$xml->methods;
    		    $_REQUEST['payment_country']  = (string)$xml->payment_country;
    		    $_REQUEST['payment_solutions']= (string)$xml->payment_solutions;
    		}

    		//securecode
    		$securecode = $this->module->getSecureCode();
    	
    	}

        //记录提交日志
        $this->module->postLog('[Browser Return]', $xml_str);

    	//交易推送
    	if(isset($_REQUEST['response_type']) && $_REQUEST['response_type'] == 1){
    		$states_list = $this->module->getStatesList();
    		
    		//签名数据
    		$local_signValue = hash("sha256",$_REQUEST['account'].$_REQUEST['terminal'].$_REQUEST['order_number'].$_REQUEST['order_currency'].$_REQUEST['order_amount'].$_REQUEST['order_notes'].$_REQUEST['card_number'].
    				$_REQUEST['payment_id'].$_REQUEST['payment_authType'].$_REQUEST['payment_status'].$_REQUEST['payment_details'].$_REQUEST['payment_risk'].$securecode);
    		
    		
    		$history = new OrderHistory();
    		$history->id_order = $_REQUEST['order_number'];
    		
    		//响应代码
    		$getErrorCode	= explode(':', $_REQUEST['payment_details']);
    		$ErrorCode      = $getErrorCode[0];
    		
    		
    		if(strtoupper($local_signValue) == strtoupper($_REQUEST['signValue'])){
    			if($ErrorCode == 20061){
    				//排除订单号重复(20061)的交易
    			}else{
    				if($_REQUEST['payment_status'] == 1 ){
    					//支付成功
    					$history->changeIdOrderState($states_list['success_states'], $_REQUEST['order_number']);
    					$history->addWithemail(true);
    		
    					$this->context->cookie->id_cart = null;
    					
    					$order_reference = Order::getUniqReferenceOf($_REQUEST['order_number']);
    					
    					$sql = "UPDATE `"._DB_PREFIX_."order_payment` SET transaction_id = '".pSQL($_REQUEST['payment_id'])."' ,
    					card_number = '".pSQL($_REQUEST['card_number'])."' where order_reference = '".pSQL($order_reference)."'";
    					Db::getInstance()->execute($sql);
    				}elseif ($_REQUEST['payment_status'] == -1 ){
    					//交易待处理
    					//是否预授权交易
    					if($_REQUEST['payment_authType'] == 1){
    						$history->changeIdOrderState($states_list['success_states'], $_REQUEST['order_number']);
    						$history->addWithemail(true);
    						
    						$this->context->cookie->id_cart = null;
    						
    						$order_reference = Order::getUniqReferenceOf($_REQUEST['order_number']);
    						
    						$sql = "UPDATE `"._DB_PREFIX_."order_payment` SET transaction_id = '".pSQL($_REQUEST['payment_id'])."' ,
    						card_number = '".pSQL($_REQUEST['card_number'])."' where order_reference = '".pSQL($order_reference)."'";
    						Db::getInstance()->execute($sql);
    					}else{
    						$history->changeIdOrderState($states_list['pending_states'], $_REQUEST['order_number']);
    					}
    				}else{
    					//支付失败
    					$history->changeIdOrderState($states_list['fail_states'], $_REQUEST['order_number']);
    				}
    			}
    		
    		}else{  //数据签名对比失败
    			$history->changeIdOrderState($states_list['fail_states'], $_REQUEST['order_number']);
    		}
    		
    		echo "receive-ok";
    		exit;
    	}
    	
    	
    	
    	//异常推送
    	if(isset($_REQUEST['notice_type']) && $_REQUEST['notice_type'] != ''){
    	    
    	    //签名数据
    	    $local_signValue = hash("sha256",$_REQUEST['account'].$_REQUEST['terminal'].$_REQUEST['order_number'].$_REQUEST['payment_id'].
    	        $_REQUEST['push_id'].$_REQUEST['push_status'].$_REQUEST['push_details'].$securecode);
    	    
    	    if(strtoupper($local_signValue) == strtoupper($_REQUEST['signValue'])){
    	            	        
    	        
    	        if($_REQUEST['notice_type'] == 'refund' || $_REQUEST['notice_type'] == 'partialRefund'){
    	            
    	            if($_REQUEST['push_status'] == 1){
    	                $status = 1;
    	            }elseif($_REQUEST['push_status'] == 0){
    	                $status = 2;
    	            }
    	            
                    $sql = "UPDATE `"._DB_PREFIX_."oceanpayment_refund_transaction` SET 
                    	status = '".pSQL($status)."' ,
                    	date_upd = NOW() 
                    	where refund_id = '".pSQL($_REQUEST['push_id'])."'";
                    Db::getInstance()->execute($sql);
    	        }elseif($_REQUEST['notice_type'] == 'chargeBack'){
    	        
    	        }elseif($_REQUEST['notice_type'] == 're-presentment'){
    	        
    	        }elseif($_REQUEST['notice_type'] == 'retrieval'){
    	        
    	        }elseif($_REQUEST['notice_type'] == 'reversal-retrieval'){
    
    	        }
    	        
    	        
    	        
    	    }
    	    
    	    echo "receive-ok";
    	    exit;
    	    
    	}
    	exit;
    }
 
    
    //判断是否为xml
    function xml_parser($str){
    	$xml_parser = xml_parser_create();
    	if(!xml_parse($xml_parser,$str,true)){
    		xml_parser_free($xml_parser);
    		return false;
    	}else {
    		return true;
    	}
    }
    
}
