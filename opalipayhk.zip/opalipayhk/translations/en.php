<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{opalipayhk}prestashop>opalipayhk_11408e1752463fd7bdd5884a02364808'] = 'Alipay HK';
$_MODULE['<{opalipayhk}prestashop>opalipayhk_2a0266dca513f7f10343416810cf1669'] = 'Oceanpayment Alipay HK.';
$_MODULE['<{opalipayhk}prestashop>opalipayhk_876f23178c29dc2552c0b48bf23cd9bd'] = 'Are you sure you want to uninstall?';
$_MODULE['<{opalipayhk}prestashop>opalipayhk_149569e882f337e585496cd3811efb1c'] = 'Configuration Updated.';
$_MODULE['<{opalipayhk}prestashop>refund_be3be682dc5c1e943ae1b5ac3f55695b'] = ' Oceanpayment Online Refund';
$_MODULE['<{opalipayhk}prestashop>refund_e50a0d4bbe5c7fbea545b519a7853515'] = 'Refund Online';
$_MODULE['<{opalipayhk}prestashop>refund_729a51874fe901b092899e9e8b31c97a'] = 'Are you sure?';
$_MODULE['<{opalipayhk}prestashop>order-confirmation_94fb1e8201ba3cc3f7ff9cd68cab0b8e'] = 'Once your card has been verified and funds have been accepted, your order will be shipped.';
$_MODULE['<{opalipayhk}prestashop>order-confirmation_f3382dc93a2d37ea38ba60012075d72e'] = 'Total of the transaction :';
$_MODULE['<{opalipayhk}prestashop>order-confirmation_a378cd7a0839cbd4ec3e45bbdeeb69be'] = 'Your order ID is :';
$_MODULE['<{opalipayhk}prestashop>order-confirmation_0db71da7150c27142eef9d22b843b4a9'] = 'For any questions or for further information, please contact our';
$_MODULE['<{opalipayhk}prestashop>order-confirmation_64430ad2835be8ad60c59e7d44e4b0b1'] = 'customer support';
$_MODULE['<{opalipayhk}prestashop>order-confirmation_8de637e24570c1edb0357826a2ad5aea'] = 'We noticed a problem with your order. If you think this is an error, you can contact our';
$_MODULE['<{opalipayhk}prestashop>payment_11408e1752463fd7bdd5884a02364808'] = 'Alipay HK';
