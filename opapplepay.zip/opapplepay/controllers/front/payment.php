<?php
/**
 * @author    Oceanpayment Team
 * @copyright Copyright (c) 2018 Oceanpayment.COM
 */
 

class OPApplePayPaymentModuleFrontController extends ModuleFrontController
{

    public function initContent()
    {

        parent::initContent();

        $cart = $this->context->cart;

        if ($cart->id_customer == 0 || $cart->id_address_delivery == 0 || $cart->id_address_invoice == 0 || !$this->module->active) {
            Tools::redirect('index.php?controller=order&step=1');
        }

        // Check that this payment option is still available in case the customer changed his address just before the end of the checkout process
        $authorized = false;
        foreach (Module::getPaymentModules() as $module) {
            if ($module['name'] == 'opapplepay') {
                $authorized = true;
                break;
            }
        }

        if (!$authorized) {
            Tools::redirect('index.php?controller=order&step=1');
        }

        $customer = new Customer($cart->id_customer);

        if (!Validate::isLoadedObject($customer)) {
            Tools::redirect('index.php?controller=order&step=1');
        }


        $transactionUrl = $this->module->getTransactionUrl();
        $payMode = $this->module->getPayMode();
        
        $parameters = $this->module->getPostParameters($cart);

        if($transactionUrl == 'production'){
            $transactionUrl = 'https://secure.oceanpayment.com/gateway/service/pay';
        }elseif($transactionUrl == 'sandbox'){
            $transactionUrl = 'https://test-secure.oceanpayment.com/gateway/service/pay';
        }
        //记录提交日志
        $this->module->postLog('[POST to Oceanpayment]', $parameters);

        $this->context->smarty->assign([
            'module_path'       => $this->module->getPathUri(),
            'nbProducts'        => $cart->nbProducts(),
            'parameters'        => $parameters,
            'transactionUrl'    => $transactionUrl,
            'payMode'           => $payMode,
        ]);

        $this->setTemplate('module:opapplepay/views/templates/front/payment.tpl');

    }


}
