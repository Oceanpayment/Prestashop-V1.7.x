<?php
/**
 * @author    Oceanpayment Team
 * @copyright Copyright (c) 2018 Oceanpayment.COM
 */
 

class OPClearpayReturniframeModuleFrontController extends ModuleFrontController
{
    public function initContent()
    {

        parent::initContent();
    	
    	if(isset($_REQUEST) && !empty($_REQUEST)){
    		$parameters = $_REQUEST;
    	}else{
    		$parameters = array();
    	}

    	$context = Context::getContext();
    	$return_url = $context->link->getModuleLink('opclearpay', 'return', []);
    	
    	$module_path = $this->module->getPathUri();
    	

    	$html = '';
    	$html .= '
<div id="loading" style="position: relative;">
    <div style="position:absolute; top:0px; left:45%; z-index:3;" >
        <img src="'.$module_path.'views/img/loading.gif"   />
    </div>
</div>
<form action="'.$return_url.'" method="post" id="form" name="form" target="_parent">';
	foreach($parameters as $k=>$v){
		$html .= '<input type="hidden" name="'.$k.'" value="'.$v.'" />';
	}
		$html .= '</form>
<script type="text/javascript">
	document.form.submit();
</script>';
		
		echo $html;
		exit;

    }
 

}
