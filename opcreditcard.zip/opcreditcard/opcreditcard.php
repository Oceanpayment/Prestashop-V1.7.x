<?php
/**
 * @author    Oceanpayment Team
 * @copyright Copyright (c) 2018 Oceanpayment.COM
 */
use PrestaShop\PrestaShop\Core\Payment\PaymentOption;

if (!defined('_PS_VERSION_')) {
    exit;
}

class OPCreditCard extends PaymentModule
{
	private $_html = '';
	protected $session;
	
	private $apply_refund_url = "https://query.oceanpayment.com/service/applyRefund";
	private $upload_tracking_no_url = "https://query.oceanpayment.com/service/uploadTrackingNo";
	
    public function __construct()
    {
        $this->name             = 'opcreditcard';
        $this->tab              = 'payments_gateways';
        $this->version          = '2.0.0';
        $this->author           = 'Oceanpayment';
        $this->is_eu_compatible = 1;
        $this->controllers      = array('payment', 'validation');

        $this->bootstrap = true;
        parent::__construct();

        $this->displayName = $this->l('Credit/Debit Card');
        $this->description = $this->l('Oceanpayment Credit/Debit Card.');

        $this->confirmUninstall = $this->l('Are you sure you want to uninstall?');

    }
    
    /**
     * 获取配置的TransactionUrl
     */
    public function getTransactionUrl()
    {
        return Configuration::get($this->name.'_TRANSACTION_URL');
    }
    
    /**
     * 获取配置的PayMode
     */
    public function getPayMode()
    {
        return Configuration::get($this->name.'_PAY_MODE');
    }
    
    /**
     * 获取配置的SecureCode
     */
    public function getSecureCode()
    {
        return Configuration::get($this->name.'_SECURECODE');
    }
    
    /**
     * 获取配置的状态列表
     */
    public function getStatesList()
    {
    	$states_list = array();
    	$states_list['unpaid_states'] = Configuration::get($this->name.'_UNPAID_STATES');
    	$states_list['success_states'] = Configuration::get($this->name.'_SUCCESS_STATES');
    	$states_list['fail_states'] = Configuration::get($this->name.'_FAIL_STATES');
    	$states_list['pending_states'] = Configuration::get($this->name.'_PENDING_STATES');
    	
    	return $states_list;
    }
    
    /**
     * 插件配置界面
     */
    public function getContent()
    {
    	global $cookie;
    	
    	$message = null;
    	
        if (Tools::isSubmit('submit' . $this->name)) 
    	{
    		Configuration::updateValue($this->name.'_ACCOUNT', trim(Tools::getValue('account')));
    		Configuration::updateValue($this->name.'_TERMINAL', trim(Tools::getValue('terminal')));
    		Configuration::updateValue($this->name.'_SECURECODE', trim(Tools::getValue('securecode')));
    		Configuration::updateValue($this->name.'_TRANSACTION_URL', trim(Tools::getValue('transaction_url')));
    		Configuration::updateValue($this->name.'_PAY_MODE', trim(Tools::getValue('pay_mode')));
    		Configuration::updateValue($this->name.'_UNPAID_STATES', trim(Tools::getValue('unpaid_states')));
    		Configuration::updateValue($this->name.'_SUCCESS_STATES', trim(Tools::getValue('success_states')));
    		Configuration::updateValue($this->name.'_FAIL_STATES', trim(Tools::getValue('fail_states')));
    		Configuration::updateValue($this->name.'_PENDING_STATES', trim(Tools::getValue('pending_states')));

			$message = $this->l('Configuration Updated.');
 
    	}
    	
    	$config = [
	    	'account'       	=> Configuration::get($this->name.'_ACCOUNT'),
	    	'terminal'     		=> Configuration::get($this->name.'_TERMINAL'),
	    	'securecode' 		=> Configuration::get($this->name.'_SECURECODE'),
	    	'transaction_url'	=> Configuration::get($this->name.'_TRANSACTION_URL'),
	    	'pay_mode'			=> Configuration::get($this->name.'_PAY_MODE'),
	    	'unpaid_states'		=> Configuration::get($this->name.'_UNPAID_STATES'),
	    	'success_states'	=> Configuration::get($this->name.'_SUCCESS_STATES'),
	    	'fail_states'		=> Configuration::get($this->name.'_FAIL_STATES'),
	    	'pending_states'	=> Configuration::get($this->name.'_PENDING_STATES'),
    	];

    	$states_list = OrderState::getOrderStates((int)($cookie->id_lang));
    	
    	$data = array(
    	    'base_url'    => _PS_BASE_URL_ . __PS_BASE_URI__,
    	    'module_name' => $this->name,
    		'states_list' => $states_list,
    		'config' => $config,
    		'message' => $message,
    	);
    	
    	$this->context->controller->addCSS($this->_path . 'views/css/configuration.css');
    	$this->context->smarty->assign($data);
    	$output = $this->display(__FILE__, 'views/templates/admin/configuration.tpl');
    	
    	return $output;
    }
    

    
    /**
     * 安装
     */
    public function install()
    {
    	parent::install();
    
    	if (!$this->registerHook('leftColumn')
    			 || !$this->registerHook('payment')
                 || !$this->registerHook('paymentOptions')
    			 || !$this->registerHook('return')
    			 || !$this->registerHook('returniframe')
    			 || !$this->registerHook('notice')
    			 || !$this->registerHook('adminOrder')
    			 || !$this->registerHook('actionAdminOrdersTrackingNumberUpdate')
    			 || !$this->createTables()
    			){
    		return false;
    	}else{
    		return true;
    	}
    		
    }
    
    /**
     * 卸载
     */
    public function uninstall()
    {
    	if (!parent::uninstall()) {
    		return false;
    	}
    
    	Configuration::deleteByName($this->name.'_ACCOUNT');
    	Configuration::deleteByName($this->name.'_TERMINAL');
    	Configuration::deleteByName($this->name.'_SECURECODE');
    	Configuration::deleteByName($this->name.'_TRANSACTION_URL');
    	Configuration::deleteByName($this->name.'_PAY_MODE');
    	Configuration::deleteByName($this->name.'_UNPAID_STATES');
    	Configuration::deleteByName($this->name.'_SUCCESS_STATES');
    	Configuration::deleteByName($this->name.'_FAIL_STATES');
    	Configuration::deleteByName($this->name.'_PENDING_STATES');

    	return true;
    }
    
    /**
     * 退款申请
     */
    public function hookAdminOrder($params)
    {
    	// session_start();
    	if (!$this->active) {
            return;
        }

        $errors = [];
        $success = [];
        
        $refund_amount = round((float) Tools::getValue('op_refund_amount', 0), 2);
        $refund_description = Tools::getValue('op_refund_description');
        

        if ($refund_amount != 0 && $refund_description != '' && (Tools::getValue('refund_token') == $_SESSION["refund_token"])) {

        	//securecode
        	$securecode = Configuration::get($this->name.'_SECURECODE');	

        	$order_reference = Order::getUniqReferenceOf($params['id_order']);
        	
        	$result = Db::getInstance()->getRow('SELECT * FROM `' . _DB_PREFIX_ . 'order_payment` WHERE order_reference = "'.$order_reference.'" AND transaction_id != "" ');
        	 
        	if (!empty($result)) {
				$payment_id = $result['transaction_id'];
        	}else{
        		$payment_id = '';
        	}
        	
        	$data = array();
        	$data['account'] = Configuration::get($this->name.'_ACCOUNT');
        	$data['terminal'] = Configuration::get($this->name.'_TERMINAL');
        	$data['payment_id'] = $payment_id;
        	$data['refund_type'] = '2';
        	$data['refund_amount'] = $refund_amount;
        	$data['refund_description'] = $refund_description;
        	$data['signValue'] = hash("sha256",$data['account'].$data['terminal'].$data['payment_id'].$data['refund_type'].$data['refund_amount'].$data['refund_description'].$securecode);
        	
        	$result_data = $this->curl_https($this->apply_refund_url, $data);
        	
        	$xml = simplexml_load_string($result_data);
        	
        	$result_data = array();
        	$result_data['refund_id']			= (string)$xml->refund_id;
        	$result_data['refund_results']		= (string)$xml->refund_results;
        	$result_data['refund_description']	= (string)$xml->refund_description;
        	

        	if($result_data['refund_results'] == '00'){
        		$sql = "INSERT INTO `"._DB_PREFIX_."oceanpayment_refund_transaction`
        		(`id_order`, `order_reference`, `transaction_id`, `refund_id`, `status`, `refund_amount`, `refund_description`, `date_add`) VALUE
        		('".$params['id_order']."', '".$order_reference."', '".$payment_id."', '".$result_data['refund_id']."', '0', '".$refund_amount."', '".$refund_description."', NOW())";
        		
        		Db::getInstance()->execute($sql);
        		
        		$success[] = 'Apply Success.';
        	}else{
        		$errors[] = $result_data['refund_results'].':'.$result_data['refund_description'];
        	}

        }
        
        $refund_token = Tools::getAdminToken(time());
        $_SESSION["refund_token"] = $refund_token;

        
        $result = Db::getInstance()->ExecuteS('SELECT * FROM `' . _DB_PREFIX_ . 'oceanpayment_refund_transaction` WHERE id_order = "'.$params['id_order'].'"');        

        if (!empty($result)) {
        	
        	foreach ($result as $i=>$details){
        		if($details['status'] == '0'){
        			$result[$i]['status'] = 'Pending';
        		}elseif($details['status'] == '1'){
        			$result[$i]['status'] = 'Complete';
        		}elseif($details['status'] == '2'){
        			$result[$i]['status'] = 'Failed';
        		}
        	}
        	$refund_record = $result;
        }else{
        	$refund_record = array();
        }
        
        
        $this->context->smarty->assign(
			[
				'base_url'					=> _PS_BASE_URL_ . __PS_BASE_URI__,
				'params'					=> $params,
				'errors_tip'				=> $errors,
				'success_tip'				=> $success,
				'refund_token'				=> $refund_token,
				'module_name'				=> $this->name,
				'refund_record'				=> $refund_record,
			]
		);

		$html = $this->display(__FILE__, 'views/templates/admin/order/refund.tpl');

		return $html;

    }
    
    
    /**
     * 物流信息上传
     */
    public function hookActionAdminOrdersTrackingNumberUpdate($params)
    {
        if (!$this->active) {
            return;
        }
        
        $order = $params['order'];
        
        
        //securecode
        $securecode = Configuration::get($this->name.'_SECURECODE');
        
        $order_reference = Order::getUniqReferenceOf($order->id);  
        
        $result = Db::getInstance()->getRow('SELECT * FROM `' . _DB_PREFIX_ . 'order_payment` WHERE order_reference = "'.$order_reference.'" AND transaction_id != "" ');
        
        if (!empty($result)) {
            $payment_id = $result['transaction_id'];
        }else{
            $payment_id = '';
        }
         
        $data = array();
        $data['account'] = Configuration::get($this->name.'_ACCOUNT');
        $data['terminal'] = Configuration::get($this->name.'_TERMINAL');
        $data['payment_id'] = $payment_id;
        $data['tracking_number'] = $order->shipping_number;
        $data['tracking_site'] = 'N/A';
        $data['tracking_handler'] = 'System';
        $data['signValue'] = hash("sha256",$data['account'].$data['terminal'].$data['payment_id'].$data['tracking_number'].$data['tracking_site'].$data['tracking_handler'].$securecode);
         
        $result_data = $this->curl_https($this->upload_tracking_no_url, $data);
         
        $xml = simplexml_load_string($result_data);
         
        $result_data = array();
        $result_data['tracking_results']    = (string)$xml->tracking_results;
        
    }
    
    /**
     * 支付前端
     */
    public function hookPayment()
    {
    	if (!$this->active) {
    		return;
    	}

    	$module_dir = parent::getPathUri();
    
    	$context = Context::getContext();
    	$link    = $context->link->getModuleLink('opcreditcard', 'payment', []);
    	
    	$this->context->smarty->assign([
    			'module_path'     => $module_dir,
    			'controller_link' => $link,
    			]);
    
    	return $this->display(__FILE__, 'views/templates/hook/payment.tpl');
    }

    /**
     * 支付前端
     */
    public function hookPaymentOptions($params)
    {
        if (!$this->active) {
            return;
        }

        if (!$this->checkCurrency($params['cart'])) {
            return;
        }

        $module_dir = parent::getPathUri();
    
        $context = Context::getContext();
        $link    = $context->link->getModuleLink('opcreditcard', 'payment', []);

        $transaction_url = Configuration::get($this->name.'_TRANSACTION_URL');
        $sandbox_note = '';
        if($transaction_url == 'sandbox'){
            $sandbox_note = 'Note: In the test state all transactions are not deducted and cannot be shipped or services provided. The interface needs to be closed in time after the test is completed to avoid consumers from placing orders.';
        }

        $this->smarty->assign([
                'module_path'     => $module_dir,
                'controller_link' => $link,
                'sandbox_note'    => $sandbox_note
        ]);

        $newOption = new PaymentOption();
        $newOption->setModuleName($this->name)
                ->setCallToActionText('Credit/Debit Card')
                ->setAction($this->context->link->getModuleLink($this->name, 'payment', array(), true))
                ->setAdditionalInformation($this->fetch('module:opcreditcard/views/templates/hook/payment.tpl'));

        return [$newOption];
    }

    public function checkCurrency($cart)
    {
        $currency_order = new Currency($cart->id_currency);
        $currencies_module = $this->getCurrency($cart->id_currency);

        if (is_array($currencies_module)) {
            foreach ($currencies_module as $currency_module) {
                if ($currency_order->id == $currency_module['id_currency']) {
                    return true;
                }
            }
        }
        return false;
    }
    
    /**
     * 请求表单
     */
    public function getPostParameters($cart)
    {
        if (!$this->active)
            return;
        
        global $smarty;
        

        $billingAddress = new Address(intval($cart->id_address_invoice));
        $shippingAddress = new Address(intval($cart->id_address_delivery));
        $customer = new Customer(intval($cart->id_customer));
        $productDetails = $this->getProductItems($cart->getProducts());
        $currency = new Currency((int)$cart->id_currency);
        
        $billingCountry = new Country((int) $billingAddress->id_country);
        $shippingCountry = new Country((int) $shippingAddress->id_country);

        $context = Context::getContext();
        
        $total = (float) $cart->getOrderTotal();
        
        $payMode = $this->getPayMode();
        

        //创建订单
        $this->validateOrder(
        		(int) $cart->id,
        		Configuration::get($this->name.'_UNPAID_STATES'),
        		$total,
        		$this->displayName,
        		null,
        		array(),
        		null,
        		true
        );

   
        //恢复购物车
        $duplication = $cart->duplicate();
        $this->context->cookie->id_cart = $duplication['cart']->id;
        $context->cart = $duplication['cart'];
        CartRule::autoAddToCart($context);
        $this->context->cookie->write();

        
        
        $parameters = array();

        //securecode
        $securecode = Configuration::get($this->name.'_SECURECODE');
        
        
        //账户
        $parameters['account'] = Configuration::get($this->name.'_ACCOUNT');
        //终端号
        $parameters['terminal'] = Configuration::get($this->name.'_TERMINAL');
        //交易金额
        $parameters['order_amount'] = $cart->getOrderTotal();
        //交易币种
        $parameters['order_currency'] = $currency->iso_code;
        //商户订单号	
        $parameters['order_number'] = $this->currentOrder;
        //交易返回地址
        if($payMode == 'iframe'){
        	$parameters['backUrl'] = $context->link->getModuleLink('opcreditcard', 'returniframe', []);
        }else{
        	$parameters['backUrl'] = $context->link->getModuleLink('opcreditcard', 'return', []);
        }
        //服务器响应地址
        $parameters['noticeUrl'] = $context->link->getModuleLink('opcreditcard', 'notice', []);
        //备注
        $parameters['order_notes'] = '';
        //支付方式
        $parameters['methods']  = 'Credit Card';
        
        //客人地址信息
        //客人的名
        $parameters['billing_firstName'] = $this->OceanHtmlSpecialChars($billingAddress->firstname);
        //客人的姓
        $parameters['billing_lastName'] = $this->OceanHtmlSpecialChars($billingAddress->lastname);
        //客人的邮件
        $parameters['billing_email'] = $this->OceanHtmlSpecialChars($customer->email);
        //客人的联系电话
        $parameters['billing_phone'] = empty($billingAddress->phone_mobile) ? $billingAddress->phone : $billingAddress->phone_mobile;
        //客人的国家
        $parameters['billing_country'] = $billingCountry->iso_code;
        //客人的省或州
        $parameters['billing_state'] = State::getNameById($billingAddress->id_state);
        //客人的城市
        $parameters['billing_city'] = $billingAddress->city;
        //客人的地址
        $parameters['billing_address'] = $billingAddress->address1;
        //客人的邮编
        $parameters['billing_zip'] = $billingAddress->postcode;
        
        //收货人地址信息
        //收货人名
        $parameters['ship_firstName'] = $this->OceanHtmlSpecialChars($shippingAddress->firstname);
        //收货人姓
        $parameters['ship_lastName'] = $this->OceanHtmlSpecialChars($shippingAddress->lastname);
        //收货人手机
        $parameters['ship_phone'] = empty($shippingAddress->phone_mobile) ? $shippingAddress->phone : $shippingAddress->phone_mobile;
        //收货人国家
        $parameters['ship_country'] = $shippingCountry->iso_code;
        //收货人州
        $parameters['ship_state'] = State::getNameById($shippingAddress->id_state);
        //收货人城市
        $parameters['ship_city'] = $shippingAddress->city;
        //收货人地址
        $parameters['ship_addr'] = $shippingAddress->address1;
        //收货人邮编
        $parameters['ship_zip'] = $shippingAddress->postcode;
        //产品名称
        $parameters['productName'] = $productDetails['productName'];
        //产品SKU
        $parameters['productSku'] = $productDetails['productSku'];
        //产品数量
        $parameters['productNum'] = $productDetails['productNum'];
        //购物车类型
        $parameters['cart_info'] = 'Prestashop '._PS_VERSION_;
        //版本信息
        $parameters['cart_api'] = 'V2.0.0';
        //组合加密项
        $signsrc  = $parameters['account'].$parameters['terminal'].$parameters['backUrl'].$parameters['order_number'].$parameters['order_currency'].
                    $parameters['order_amount'].$parameters['billing_firstName'].$parameters['billing_lastName'].$parameters['billing_email'].$securecode;
        //sha256加密
        $parameters['signValue']  = hash("sha256", $signsrc);

        
        return $parameters;

    }

    // function validateOrder($id_cart, $id_order_state, $amountPaid, $paymentMethod = 'Unknown', $message = NULL, $extraVars = array (), $currency_special = NULL, $dont_touch_amount = false) {
    // 	parent::validateOrder($id_cart, $id_order_state, $amountPaid, $paymentMethod, $message, $extraVars, $currency_special, true);
    // }

    /**
     * 获取订单详情
     */
    function getProductItems($AllItems){
    
        $productDetails = array();
        $productName = array();
        $productSku = array();
        $productNum = array();

        foreach ($AllItems as $item) {
            $productName[] = $item['name'];
            $productSku[] = $item['id_product'];
            $productNum[] = $item['cart_quantity'];
            $productPrice[] = $item['total_wt'];
        }
    
        $productDetails['productName'] = implode(';', $productName);
        $productDetails['productSku'] = implode(';', $productSku);
        $productDetails['productNum'] = implode(';', $productNum);
        $productDetails['productPrice'] = implode(';', $productPrice);
    
        return $productDetails;
    
    }
    
    
    
    /**
     * 钱海支付Html特殊字符转义
     */
    function OceanHtmlSpecialChars($parameter){

        //去除前后空格
        $parameter = trim($parameter);
    
        if($parameter != ''){
            //转义"双引号,<小于号,>大于号,'单引号
            $parameter = str_replace(array("<",">","'","\""),array("&lt;","&gt;","&#039;","&quot;"),$parameter);
        }
    
        return $parameter;
    
    }
    
    
    
    protected function createTables()
    {
    	if (!Db::getInstance()->Execute('
    			CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'oceanpayment_refund_transaction` (
    			`id` int NOT NULL AUTO_INCREMENT,
    			`id_order` int(10) unsigned NOT NULL,
    			`order_reference` varchar(9) NOT NULL,
    			`transaction_id` varchar(255) NOT NULL,
    			`refund_id` varchar(50) NOT NULL,
    			`status` varchar(50) NOT NULL,
    			`refund_amount` decimal(20,2) NOT NULL DEFAULT \'0.00\',
    			`refund_description` varchar(200) NOT NULL,
    			`date_add` datetime NOT NULL,
    			`date_upd` datetime NOT NULL,
    			PRIMARY KEY (`id`)
    	) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8')
    	) {
    		return false;
    	}
    
    	return true;
    }
    
    
    /**
     *  Curl函数
     *
     */
    function curl_https($url, $data){
    
    	$ch = curl_init();
    	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); // 跳过证书检查
    	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false); // 从证书中检查SSL加密算法是否存在
    	curl_setopt($ch, CURLOPT_URL, $url);
    	curl_setopt($ch, CURLOPT_POST, true);
    	curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
    	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    	curl_setopt($ch, CURLOPT_TIMEOUT, 300);
    
    	$response = curl_exec($ch);
    
    	if (curl_errno($ch)) {
    		echo 'Curl Error:'.curl_error($ch);//捕抓异常
    		exit;
    	}
    
    	curl_close($ch);
    
    	return $response;
    
    }
}
