
{if $message}
	<div class="bootstrap">
		<div class="module_confirmation conf confirm alert alert-success">
			<button type="button" class="close" data-dismiss="alert">×</button>
			{$message|escape:'htmlall':'UTF-8'}
		</div>
	</div>
{/if}

<div class="row">
    <div class="oceanpayment">
        <img width="400px" src="{$base_url|escape:'htmlall':'UTF-8'}modules/{$module_name|escape:'htmlall':'UTF-8'}/views/img/oceanpayment.svg" alt="Oceanpayment">
        <div class="title">One-stop Cross-border Payment Solution Provider</div>

        <div class="buttons">
            <a target="_blank" href="https://accounts.oceanpayment.com/service/admin/login" class="btn">Oceanpayment Merchant Portal</a>
        </div>
    </div>
</div>
<form id="configuration_form" class="defaultForm form-horizontal opklarna" method="post" enctype="multipart/form-data" novalidate="">
	<input type="hidden" name="submitopklarna" value="1">
	<div class="panel" id="fieldset_0">
		<div class="panel-heading">
			<i class="icon-cogs"></i>Configuration
		</div>
		<div class="form-wrapper">
			<div class="form-group">
				<label class="control-label col-lg-3 required">Account</label>
				<div class="col-lg-5">
					<input type="text" name="account" id="account" value="{$config['account']}" class="" size="20" required="required">
				</div>
			</div>
			<div class="form-group">
				<label class="control-label col-lg-3 required">Terminal</label>
				<div class="col-lg-5">
					<input type="text" name="terminal" id="terminal" value="{$config['terminal']}" class="" size="20" required="required">
				</div>
			</div>
			<div class="form-group">
				<label class="control-label col-lg-3 required">SecureCode</label>
				<div class="col-lg-5">
					<input type="text" name="securecode" id="securecode" value="{$config['securecode']}" class="" size="20" required="required">
				</div>
			</div>
			<div class="form-group">
				<label class="control-label col-lg-3 required">Transaction URL</label>
				<div class="col-lg-5">
					<select name="transaction_url" class="fixed-width" id="transaction_url" >
						<option value="sandbox" {if $config['transaction_url']=='sandbox'} selected="selected" {/if} >Sandbox</option>
						<option value="production" {if $config['transaction_url']=='production'} selected="selected" {/if} >Production</option>
					</select>
					<p>Note: In the test state all transactions are not deducted and cannot be shipped or services provided. The interface needs to be closed in time after the test is completed to avoid consumers from placing orders.</p>
				</div>
			</div>
			<div class="form-group">
				<label class="control-label col-lg-3 required">Pay Mode</label>
				<div class="col-lg-5">
		            <select name="pay_mode" class="fixed-width" id="pay_mode" >
		            	<option value="iframe" {if $config['pay_mode']=='iframe'} selected="selected" {/if} >Iframe</option>
		            	<option value="redirect" {if $config['pay_mode']=='redirect'} selected="selected" {/if} >Redirect</option>
					</select>
				</div>
			</div>
			<div class="form-group">
				<label class="control-label col-lg-3 required">Unpaid States</label>
				<div class="col-lg-5">
		            <select name="unpaid_states" class="fixed-width" id="unpaid_states" >
		            	{foreach from=$states_list item=states}
		            		<option value="{$states['id_order_state']}" {if $config['unpaid_states']==$states['id_order_state']} selected="selected" {/if} >{$states['name']|escape:'htmlall':'UTF-8'}</option>
			            {/foreach}
					</select>
				</div>
			</div>
			<div class="form-group">
				<label class="control-label col-lg-3 required">Success States</label>
				<div class="col-lg-5">
		            <select name="success_states" class="fixed-width" id="success_states" >
		            	{foreach from=$states_list item=states}
		            		<option value="{$states['id_order_state']}" {if $config['success_states']==$states['id_order_state']} selected="selected" {/if} >{$states['name']|escape:'htmlall':'UTF-8'}</option>
			            {/foreach}
					</select>
				</div>
			</div>
			<div class="form-group">
				<label class="control-label col-lg-3 required">Fail States</label>
				<div class="col-lg-5">
		            <select name="fail_states" class="fixed-width" id="fail_states" >
		            	{foreach from=$states_list item=states}
		            		<option value="{$states['id_order_state']}" {if $config['fail_states']==$states['id_order_state']} selected="selected" {/if} >{$states['name']|escape:'htmlall':'UTF-8'}</option>
			            {/foreach}
					</select>
				</div>
			</div>
			<div class="form-group">
				<label class="control-label col-lg-3 required">Pending States</label>
				<div class="col-lg-5">
		            <select name="pending_states" class="fixed-width" id="pending_states" >
		            	{foreach from=$states_list item=states}
		            		<option value="{$states['id_order_state']}" {if $config['pending_states']==$states['id_order_state']} selected="selected" {/if} >{$states['name']|escape:'htmlall':'UTF-8'}</option>
			            {/foreach}
					</select>
				</div>
			</div>
		</div>
		<!-- /.form-wrapper -->
		<div class="panel-footer">
			<button type="submit" value="1" id="configuration_form_submit_btn" name="submitopklarna" class="btn btn-default pull-right">
				<i class="process-icon-save"></i> Save
			</button>
		</div>
	</div>
</form>


