
<div class="row">
    <div class="col-lg-12">
        <div class="panel">
            <div class="panel-heading"><img src="{$base_url|escape:'htmlall':'UTF-8'}modules/{$module_name|escape:'htmlall':'UTF-8'}/logo.gif"
                                            alt="" width="70px"/> {l s='Oceanpayment Online Refund' mod='opklarna'}</div>
            {foreach from=$errors_tip item=error}
                <p class="alert alert-danger">{$error|escape:'htmlall':'UTF-8'}</p>
            {/foreach}
            {foreach from=$success_tip item=success}
                <p class="alert alert-success">{$success|escape:'htmlall':'UTF-8'}</p>
            {/foreach}
            <form method="post" action="{$smarty.server.REQUEST_URI|escape:'htmlall':'UTF-8'}" onsubmit="return send_refund()">
                <input type="hidden" name="id_order" value="{$params.id_order|intval}"/>
                <input type="hidden" name="refund_token" value="{$refund_token}"/>

				<table class="table">
					<thead>
						<tr>
							<th><span class="title_box ">Apply Date</span></th>
							<th><span class="title_box ">Update Date</span></th>
							<th><span class="title_box ">Refund ID</span></th>
							<th><span class="title_box ">Refund Amount</span></th>
							<th><span class="title_box ">Refund Description</span></th>
							<th><span class="title_box ">Status</span></th>
							<th></th>
						</tr>
					</thead>
					<tbody>
						{foreach from=$refund_record item=details}
						<tr>
							<td>{$details.date_add}</td>
							<td>{$details.date_upd}</td>
							<td>{$details.refund_id}</td>
							<td>{$details.refund_amount}</td>
							<td>{$details.refund_description}</td>
							<td>{$details.status}</td>
							<td></td>
						</tr>
						{/foreach}
						
						<tr class="current-edit hidden-print">
							<td></td>
							<td></td>
							<td></td>
							<td>
								<input type="text" name="op_refund_amount" value="" class="form-control fixed-width-sm">
							</td>
							<td>
								<input type="text" name="op_refund_description" value="" class="form-control fixed-width-sm"></td>
							</td>
							<td></td>
							<td class="actions">
								<button class="btn btn-primary" type="submit" name="submitOceanpaymentOnlineRefund" >
									{l s='Refund Online' mod='opklarna'}
								</button>
							</td>
						</tr>
					</tbody>
				</table>

            </form>
        </div>
    </div>
</div>
<script type="text/javascript">
function send_refund(obj){
	if (confirm('{l s='Are you sure?' mod='opklarna'}')){
		$('button[name="submitOceanpaymentOnlineRefund"]').attr('disabled', true);
		$('button[name="submitOceanpaymentOnlineRefund"]').html('loading...');
		return true;
	}else{
		return false;
	}
}
</script>