{extends "$layout"}

{block name="content"}
  <section>
    <div class="row">
        <div class="col-md-12">

			{if $payment_status == 1 || $payment_status == -1}
				<p class="alert alert-success" style="color:green">{$payment_details}</p>
				
				<p>{l s='Once your card has been verified and funds have been accepted, your order will be shipped.' mod='opklarna'}</p>
				<p>{l s='Total of the transaction :' mod='opklarna'} <span class="confirmation-bold">{$order_currency|escape:'htmlall':'UTF-8'}  {$order_amount|escape:'htmlall':'UTF-8'}</span></p>
				<p>{l s='Your order ID is :' mod='opklarna'}
					<span class="confirmation-bold">{$order_number|escape:'htmlall':'UTF-8'}</span>
				</p>
				<p>{l s='For any questions or for further information, please contact our' mod='opklarna'} <a href="{$link->getPageLink('contact-us.php', true)|escape:'htmlall':'UTF-8'}">{l s='customer support' mod='opklarna'}</a>.</p>
			{else}
				<p class="alert alert-danger">{$payment_details}</p>
				
				{if $payment_solutions != ''}
					<p class="alert alert-warning" >{$payment_solutions}</p>
				{/if}

				<p>
					{l s='We noticed a problem with your order. If you think this is an error, you can contact our' mod='opklarna'}
					<a href="{$link->getPageLink('contact-us.php', true)|escape:'htmlall':'UTF-8'}">{l s='customer support' mod='opklarna'}</a>.
				</p>
			{/if}
    	</div>
	</div>
  </section>
{/block}
