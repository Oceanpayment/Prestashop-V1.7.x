{extends "$layout"}

{block name="content"}
  <section>
    <div class="row">
        <div class="col-md-12">
            <div id="loading" style="position: relative;">
              <div style="position:absolute; top:0px; left:45%; z-index:3;" >
                <img src="{$module_path}views/img/loading.gif"   />
              </div>
            </div>
        </div>
        <form action="{$transactionUrl}" method="post" id="klarna_payment_checkout" name="klarna_payment_checkout" >
            {foreach from=$parameters item=val key=k}
              <input type="hidden" name="{$k}" value="{$val}" />
            {/foreach}
        </form>
        {if isset($payMode) && $payMode == 'iframe'}
          <iframe scrolling="auto" id="ifrm_klarna_checkout" name="ifrm_klarna_checkout" frameborder="no"  width="100%"  height="760px" ></iframe>
          
            <script type="text/javascript">
              document.klarna_payment_checkout.target="ifrm_klarna_checkout";
              document.klarna_payment_checkout.submit();
            var ifrm_cc  = document.getElementById("ifrm_klarna_checkout");
            var loading  = document.getElementById("loading");
            if (ifrm_cc.attachEvent){
                ifrm_cc.attachEvent("onload", function(){
                    loading.style.display = 'none';
                });
            } else {
                ifrm_cc.onload = function(){
                    loading.style.display = 'none';
                };
            }
          </script>
        {else}
          <script type="text/javascript">
              document.klarna_payment_checkout.submit();
          </script>
        {/if}
    </div>

  </section>
{/block}



