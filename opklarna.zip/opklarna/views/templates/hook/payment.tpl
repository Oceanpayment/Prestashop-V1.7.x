
<p class="payment_module">
	<img src="{$module_path|escape:'htmlall':'UTF-8'}views/img/pay_logo.png" alt="{l s='Klarna' mod='Klarna'}"/>
</p>
<p style="color: red;">
	{$sandbox_note}
</p>
