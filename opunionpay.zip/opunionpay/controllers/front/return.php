<?php
/**
 * @author    Oceanpayment Team
 * @copyright Copyright (c) 2018 Oceanpayment.COM
 */
 

class OPUnionpayReturnModuleFrontController extends ModuleFrontController
{
    public function initContent()
    {

        parent::initContent();

        $cart = $this->context->cart;

        if ($cart->id_customer == 0 || $cart->id_address_delivery == 0 || $cart->id_address_invoice == 0 || !$this->module->active) {
            Tools::redirect('index.php?controller=order&step=1');
        }
        //记录提交日志
        $this->module->postLog('[Browser Return]', $_REQUEST);
        //账户
        $account = $_REQUEST['account'];
        //终端号
        $terminal = $_REQUEST['terminal'];
        //securecode
        $securecode = $this->module->getSecureCode();
        //交易流水订单号
        $payment_id = $_REQUEST['payment_id'];
        //返回网站订单号
        $order_number = $_REQUEST['order_number'];
        //交易币种
        $order_currency = $_REQUEST['order_currency'];
        //交易金额
        $order_amount = $_REQUEST['order_amount'];
        //交易状态
        $payment_status = $_REQUEST['payment_status'];
        //返回支付详情
        $payment_details = $_REQUEST['payment_details'];
        //未通过的风控规则
        $payment_risk = $_REQUEST['payment_risk'];
        //返回支付信用卡卡号
        $card_number = $_REQUEST['card_number'];
        //返回交易类型
        $payment_authType = $_REQUEST['payment_authType'];
        //备注
        $order_notes = $_REQUEST["order_notes"];
        //数据签名
        $back_signValue = $_REQUEST["signValue"];
        //返回解决办法
        $payment_solutions = $_REQUEST['payment_solutions'];
        
        //校验源字符串
        $local_signValue = hash("sha256",$account.$terminal.$order_number.$order_currency.$order_amount.$order_notes.$card_number.
            $payment_id.$payment_authType.$payment_status.$payment_details.$payment_risk.$securecode);
        
        //是否推送
        $response_type = $_REQUEST['response_type'];
        
        //用于支付结果页面显示响应代码
        $getErrorCode = explode(':', $payment_details);
        $ErrorCode = $getErrorCode[0];

        
        $states_list = $this->module->getStatesList();
        

        $history = new OrderHistory();
        $history->id_order = $order_number;

        $transaction_url = Configuration::get('opunionpay_TRANSACTION_URL');
        if($transaction_url == 'sandbox'){
            $payment_details = 'TEST ORDER-'.$payment_details;
            $payment_id = 'TEST ORDER-'.$payment_id;
        }
        if(strtoupper($local_signValue) == strtoupper($back_signValue)){
        	if($ErrorCode == 20061){
        		//排除订单号重复(20061)的交易
        	}else{
        		if($payment_status == 1 ){
        			//支付成功
        			$history->changeIdOrderState($states_list['success_states'], $order_number);
        			$history->addWithemail(true);
        				
        			$this->context->cookie->id_cart = null;
        			
        			$order_reference = Order::getUniqReferenceOf($order_number);

        			$sql = "UPDATE `"._DB_PREFIX_."order_payment` SET transaction_id = '".pSQL($payment_id)."' ,
        				 card_number = '".pSQL($card_number)."' where order_reference = '".pSQL($order_reference)."'";
        			Db::getInstance()->execute($sql);
        			
        		}elseif ($payment_status == -1 ){
        			//交易待处理
        			//是否预授权交易
        			if($payment_authType == 1){
        				$history->changeIdOrderState($states_list['success_states'], $order_number);
        				$history->addWithemail(true);
        				
        				$this->context->cookie->id_cart = null;
        				
        				$order_reference = Order::getUniqReferenceOf($order_number);
        				
        				$sql = "UPDATE `"._DB_PREFIX_."order_payment` SET transaction_id = '".pSQL($payment_id)."' ,
        				card_number = '".pSQL($card_number)."' where order_reference = '".pSQL($order_reference)."'";
        				Db::getInstance()->execute($sql);
        			}else{
        				$history->changeIdOrderState($states_list['pending_states'], $order_number);
        			}
        		}else{
        			//支付失败
        			$history->changeIdOrderState($states_list['fail_states'], $order_number);
        		}
        	}
        
        }else{  //数据签名对比失败
        	$history->changeIdOrderState($states_list['fail_states'], $order_number);
        }


        $this->context->smarty->assign([
            'is_guest' 			=> (($this->context->customer->is_guest) || $this->context->customer->id == false),
        	'order_currency'	=> $order_currency,
            'order_amount' 		=> $order_amount,
            'order_number'		=> $order_number,
        	'payment_status'	=> $payment_status,
        	'payment_details'	=> $payment_details,
        	'payment_solutions'	=> $payment_solutions,
        ]);


        $this->setTemplate('module:opunionpay/views/templates/front/order-confirmation.tpl');
    }
 

}
